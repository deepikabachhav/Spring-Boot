package com.moneymoney.app.entity;

public interface TransactionType {
	public static final String WITHDRAW="Debit";
	public static final String DEPOSIT="Credit";
}
